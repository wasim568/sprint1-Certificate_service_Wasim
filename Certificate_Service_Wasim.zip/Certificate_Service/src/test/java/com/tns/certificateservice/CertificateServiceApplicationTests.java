package com.tns.certificateservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CertificateServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
